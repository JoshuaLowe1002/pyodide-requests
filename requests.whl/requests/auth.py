
def _basic_auth_str():
    ...


class AuthBase:
    ...
